# Muhammed Niyas portfolio: previous version (3D hero)

The light Poppins/orange 3D hero, with the dark serif site below it. This is the version before the full dark + lime rebuild.

    npm install
    node build.mjs              # writes dist/ (deploy this folder)
    node build.mjs --preview    # writes preview/ for local viewing
    python3 -m http.server -d preview

Content is in data/. In data/site.json, set heroMain and heroSupport (photo paths in static/assets/img/), cv, portrait, linkedin and domain to switch those items on.
Deploy the dist/ folder to any static host (Netlify drop, Vercel, GitHub Pages, cPanel).
