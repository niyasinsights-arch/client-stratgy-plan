// All motion lives here. Every effect explains, guides or rewards; reduced-motion users get none of it.
export function initMotion(ctx) {
  const root = document.documentElement;
  const done = () => root.classList.add('ready');
  if (ctx.reduced || !window.gsap || !window.ScrollTrigger) return done();
  gsap.registerPlugin(ScrollTrigger, SplitText, Flip);
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;

  if (window.Lenis) {
    const lenis = (ctx.lenis = new Lenis({ anchors: { offset: -72 }, lerp: 0.12 }));
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((t) => lenis.raf(t * 1000));
    gsap.ticker.lagSmoothing(0);
  }

  const lines = (el, vars) => {
    const split = SplitText.create(el, { type: 'lines', mask: 'lines' });
    return gsap.from(split.lines, { yPercent: 105, duration: 1.1, ease: 'expo.out', stagger: 0.07, ...vars, onComplete: () => split.revert() });
  };

  // below-the-fold start states are set here, never in CSS, so nothing is stuck hidden without JS
  const reveals = gsap.utils.toArray('[data-reveal]');
  gsap.set(reveals, { autoAlpha: 0, y: 24 });
  gsap.set('[data-index]', { autoAlpha: 0, x: -8 });
  gsap.set('[data-h2]', { autoAlpha: 0 });

  const fonts = Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 1200))]);
  fonts.then(() => {
    // load sequence: H1 lines, then sub, CTAs, ledger, proof strip
    const load = gsap.utils.toArray('.hero [data-load]');
    done();
    if (load.length) {
      gsap.set(load, { visibility: 'visible' });
      const hero = document.querySelector('[data-hero]');
      const frame = hero.querySelector('[data-hero-frame]');
      const h1 = hero.querySelector('[data-hero-h1]');
      const desktop = matchMedia('(min-width: 1024px)').matches;

      // load: nav, headline line by line, copy, main portrait, second portrait, then the cards in turn
      gsap.from('[data-header]', { autoAlpha: 0, duration: 0.8, ease: 'power2.out', clearProps: 'opacity,visibility' });
      const tl = gsap.timeline({ defaults: { ease: 'expo.out' } });
      if (matchMedia('(min-width: 600px)').matches) tl.from(h1.querySelectorAll('.hi'), { yPercent: 110, duration: 1.1, stagger: 0.09 }, 0.1);
      else tl.from(h1, { autoAlpha: 0, y: 16, duration: 0.9 }, 0.1);
      tl.from('.hero [data-in="text"]', { autoAlpha: 0, y: 20, duration: 0.8, stagger: 0.08 }, 0.35)
        .from('.hero [data-in="main"]', { autoAlpha: 0, y: desktop ? 60 : 30, scale: 0.94, duration: 1.2 }, 0.4)
        .from('.hero [data-in="support"]', { autoAlpha: 0, y: desktop ? 40 : 20, scale: 0.96, duration: 1.1 }, 0.65)
        .from('.hero [data-in="card"]', { autoAlpha: 0, y: 24, scale: 0.92, duration: 0.8, stagger: 0.1 }, 0.9);

      // scroll: every layer drifts at its own speed, the copy eases away, the frame settles back
      const k = desktop ? 1 : 0.4;
      const st = { trigger: hero, start: 'top top', end: 'bottom top', scrub: true };
      hero.querySelectorAll('[data-scroll]').forEach((el) => gsap.to(el, { y: Number(el.dataset.scroll) * k, ease: 'none', scrollTrigger: st }));
      gsap.to('[data-hero-copy]', { y: -40 * k, autoAlpha: 0, ease: 'none', scrollTrigger: { trigger: hero, start: '25% top', end: '80% top', scrub: true } });
      if (desktop) gsap.to(frame, { scale: 0.965, ease: 'none', scrollTrigger: { trigger: hero, start: '40% top', end: 'bottom top', scrub: true } });

      // cursor: the scene tilts a few degrees, layers shift by depth, the key light follows. Desktop pointers only.
      if (fine && desktop) {
        const scene = hero.querySelector('[data-scene]');
        gsap.set(scene, { transformPerspective: 1200, transformOrigin: '50% 85%' });
        const ry = gsap.quickTo(scene, 'rotationY', { duration: 0.9, ease: 'power3.out' });
        const rx = gsap.quickTo(scene, 'rotationX', { duration: 0.9, ease: 'power3.out' });
        const layers = [...hero.querySelectorAll('[data-depth]')].map((el) => ({ d: Number(el.dataset.depth), x: gsap.quickTo(el, 'x', { duration: 0.9, ease: 'power3.out' }), y: gsap.quickTo(el, 'y', { duration: 0.9, ease: 'power3.out' }) }));
        const move = (nx, ny) => { ry(nx * 5); rx(-ny * 3.5); layers.forEach((l) => { l.x(nx * l.d); l.y(ny * l.d * 0.6); }); };
        hero.addEventListener('pointermove', (e) => {
          const r = frame.getBoundingClientRect();
          const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
          move(px * 2 - 1, py * 2 - 1);
          frame.style.setProperty('--lx', `${(px * 100).toFixed(1)}%`); frame.style.setProperty('--ly', `${(py * 100).toFixed(1)}%`);
        });
        hero.addEventListener('pointerleave', () => move(0, 0));
      }
    }
    const caseH1 = document.querySelector('[data-load-h1]');
    if (caseH1) gsap.from('.case-head .container > *:not(h1)', { autoAlpha: 0, y: 16, duration: 0.8, ease: 'expo.out', stagger: 0.06, delay: 0.15 });

    // section headers: index ticks in, then the H2 lines reveal
    gsap.utils.toArray('[data-h2]').forEach((h2) => {
      const index = h2.closest('.ledger, .container')?.querySelector('[data-index]');
      ScrollTrigger.create({
        trigger: h2, start: 'top 88%', once: true,
        onEnter: () => {
          if (index) gsap.to(index, { autoAlpha: 1, x: 0, duration: 0.3, ease: 'power2.out' });
          gsap.set(h2, { autoAlpha: 1 });
          lines(h2, { duration: 0.9, delay: 0.1 });
        },
      });
    });

    ScrollTrigger.batch(reveals, { start: 'top 90%', once: true, onEnter: (els) => gsap.to(els, { autoAlpha: 1, y: 0, duration: 0.8, ease: 'expo.out', stagger: 0.07, overwrite: true }) });

    // featured cards: media wipes open, inner content drifts on scrub
    gsap.utils.toArray('[data-card]').forEach((card) => {
      const media = card.querySelector('[data-media]');
      const inner = media.querySelector('.doubt, img');
      gsap.fromTo(media, { clipPath: 'inset(0 0 100% 0)' }, { clipPath: 'inset(0 0 0% 0)', duration: 0.9, ease: 'expo.out', scrollTrigger: { trigger: card, start: 'top 82%', once: true } });
      gsap.from(card.querySelector('.card-text'), { autoAlpha: 0, y: 24, duration: 0.8, ease: 'expo.out', delay: 0.15, scrollTrigger: { trigger: card, start: 'top 82%', once: true } });
      if (inner) gsap.fromTo(inner, { yPercent: 6 }, { yPercent: -6, ease: 'none', scrollTrigger: { trigger: card, start: 'top bottom', end: 'bottom top', scrub: true } });
    });

    // method: the signal line scrubs across (or down) the steps
    const steps = document.querySelector('[data-steps]');
    if (steps) {
      const mm = gsap.matchMedia();
      const line = steps.querySelector('[data-steps-line]');
      mm.add('(min-width: 1024px)', () => { gsap.fromTo(line, { scaleX: 0, scaleY: 1 }, { scaleX: 1, ease: 'none', scrollTrigger: { trigger: steps, start: 'top 80%', end: 'bottom 55%', scrub: true } }); });
      mm.add('(max-width: 1023px)', () => { gsap.fromTo(line, { scaleY: 0, scaleX: 1 }, { scaleY: 1, ease: 'none', scrollTrigger: { trigger: steps, start: 'top 75%', end: 'bottom 60%', scrub: true } }); });
    }

    // experience: the timeline fills with scroll progress
    const tl = document.querySelector('[data-timeline]');
    if (tl) gsap.to('[data-timeline-fill]', { scaleY: 1, ease: 'none', scrollTrigger: { trigger: tl, start: 'top 70%', end: 'bottom 70%', scrub: true } });

    // primary CTA: magnetic pull, 6px at most
    if (fine) {
      document.querySelectorAll('[data-magnetic]').forEach((el) => {
        const x = gsap.quickTo(el, 'x', { duration: 0.3, ease: 'power2.out' }), y = gsap.quickTo(el, 'y', { duration: 0.3, ease: 'power2.out' });
        el.addEventListener('pointermove', (e) => { const r = el.getBoundingClientRect(); x(((e.clientX - r.left) / r.width - 0.5) * 12); y(((e.clientY - r.top) / r.height - 0.5) * 12); });
        el.addEventListener('pointerleave', () => { x(0); y(0); });
      });
    }
    ScrollTrigger.refresh();
  });
  addEventListener('pagehide', () => ScrollTrigger.getAll().forEach((t) => t.kill()));
}
