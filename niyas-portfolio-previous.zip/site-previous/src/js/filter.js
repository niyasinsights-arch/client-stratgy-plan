// Case index filter. "All" lists the seven cases not featured above; an industry lists every case in it.
export function initFilter(ctx) {
  const wrap = document.querySelector('[data-rows]');
  if (!wrap) return;
  const rows = [...wrap.querySelectorAll('[data-row]')];
  const buttons = [...document.querySelectorAll('.filter button')];
  const live = document.querySelector('[data-live]');
  const apply = (f) => {
    const animate = !ctx.reduced && window.Flip;
    const state = animate ? Flip.getState(rows) : null;
    let n = 0;
    rows.forEach((r) => {
      const on = f === 'All' ? !r.hasAttribute('data-featured') : r.dataset.filter === f;
      r.hidden = !on; if (on) n++;
    });
    buttons.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.f === f)));
    if (live) live.textContent = `${n} ${n === 1 ? 'case' : 'cases'} shown`;
    if (animate) {
      Flip.from(state, { duration: 0.5, ease: 'power2.inOut', onEnter: (els) => gsap.fromTo(els, { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.4 }), onComplete: () => window.ScrollTrigger?.refresh() });
    }
  };
  buttons.forEach((b) => b.addEventListener('click', () => apply(b.dataset.f)));
}
