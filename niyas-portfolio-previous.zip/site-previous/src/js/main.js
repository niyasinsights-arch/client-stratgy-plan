import { initNav } from './nav.js';
import { initLedger } from './ledger.js';
import { initFilter } from './filter.js';
import { initContact } from './contact.js';
import { initMotion } from './motion.js';

const ctx = { lenis: null, reduced: matchMedia('(prefers-reduced-motion: reduce)').matches };
const safe = (fn) => { try { fn(ctx); } catch (e) { console.error(e); document.documentElement.classList.add('ready'); } };
safe(initMotion); // first, so Lenis exists for the others
[initNav, initLedger, initFilter, initContact].forEach(safe);
