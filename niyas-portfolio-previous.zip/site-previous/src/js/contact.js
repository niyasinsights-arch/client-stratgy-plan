// Copy-to-clipboard for the email, with visible and announced feedback.
export function initContact() {
  const live = document.querySelector('[data-live]');
  document.querySelectorAll('[data-copy]').forEach((btn) => {
    const span = btn.querySelector('span');
    const label = span.textContent;
    btn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(btn.dataset.copy);
        btn.classList.add('is-copied');
        if (label === 'Copy') span.textContent = 'Copied';
        if (live) live.textContent = 'Copied';
        setTimeout(() => { btn.classList.remove('is-copied'); span.textContent = label; if (live) live.textContent = ''; }, 2000);
      } catch {
        if (live) live.textContent = `Copy failed. The address is ${btn.dataset.copy}`;
      }
    });
  });
}
