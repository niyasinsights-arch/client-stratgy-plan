// Hero Case Ledger: hovering or focusing an entry previews that case's Doubt line.
export function initLedger(ctx) {
  const box = document.querySelector('[data-ledger]');
  if (!box) return;
  const label = box.querySelector('[data-ledger-label]');
  const doubt = box.querySelector('[data-ledger-doubt]');
  let current = '';
  const show = (a) => {
    if (a.dataset.name === current) return;
    current = a.dataset.name;
    const swap = () => { label.textContent = `The doubt · ${a.dataset.name}`; doubt.textContent = `“${a.dataset.doubt}”`; };
    if (ctx.reduced || !window.gsap) return swap();
    gsap.killTweensOf(doubt);
    gsap.to(doubt, { autoAlpha: 0, duration: 0.12, onComplete: () => { swap(); gsap.to(doubt, { autoAlpha: 1, duration: 0.25 }); } });
  };
  box.querySelectorAll('a').forEach((a) => {
    a.addEventListener('mouseenter', () => show(a));
    a.addEventListener('focus', () => show(a));
  });
}
