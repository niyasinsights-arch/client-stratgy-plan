// Header behaviour, scroll progress, mobile menu, accordion, case-page part indicator.
export function initNav(ctx) {
  const header = document.querySelector('[data-header]');
  const bar = document.querySelector('[data-progress]');
  const root = document.documentElement;
  const hero = document.querySelector('[data-hero]');
  let last = scrollY, ticking = false;
  const update = () => {
    ticking = false;
    const y = scrollY, max = root.scrollHeight - innerHeight;
    header.classList.toggle('is-scrolled', y > 24);
    if (hero) header.classList.toggle('past-hero', y > hero.offsetHeight - 64);
    const hide = y > last && y > 240;
    if (Math.abs(y - last) > 6) { header.classList.toggle('is-hidden', hide); root.style.setProperty('--bar-top', hide ? '0px' : '64px'); last = y; }
    bar.style.transform = `scaleX(${max > 0 ? Math.min(1, y / max) : 0})`;
  };
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
  root.style.setProperty('--bar-top', '64px');
  update();

  // mobile menu: native dialog gives focus trap, Escape and focus return
  const menu = document.querySelector('[data-menu]');
  const openBtn = document.querySelector('[data-menu-open]');
  if (menu && menu.showModal) {
    openBtn.addEventListener('click', () => { menu.showModal(); ctx.lenis?.stop(); });
    menu.addEventListener('close', () => { ctx.lenis?.start(); openBtn.focus(); });
    menu.querySelector('[data-menu-close]').addEventListener('click', () => menu.close());
    menu.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => menu.close()));
  }

  // accordion (content is open without JS; the .js class collapses closed panels)
  document.querySelectorAll('[data-acc] .acc-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const open = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!open));
      document.getElementById(btn.getAttribute('aria-controls')).classList.toggle('is-open', !open);
      setTimeout(() => window.ScrollTrigger?.refresh(), 450);
    });
  });

  // case page: highlight the part being read
  const parts = [...document.querySelectorAll('[data-part]')];
  const nav = document.querySelector('[data-parts]');
  if (parts.length && nav && 'IntersectionObserver' in window) {
    const links = new Map([...nav.querySelectorAll('a')].map((a) => [a.getAttribute('href').slice(1), a]));
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (!e.isIntersecting) return;
        links.forEach((a) => a.removeAttribute('aria-current'));
        const a = links.get(e.target.id);
        a.setAttribute('aria-current', 'true');
        const ol = a.closest('ol');
        ol.scrollTo({ left: a.offsetLeft - ol.offsetLeft - 16, behavior: ctx.reduced ? 'auto' : 'smooth' });
      });
    }, { rootMargin: '-35% 0px -60% 0px' });
    parts.forEach((p) => io.observe(p));
  }
}
