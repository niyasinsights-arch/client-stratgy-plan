// Parses Section 13 of the master prompt into /data/*.json. Content is copied verbatim, never invented.
import fs from 'node:fs';
const src = process.argv[2];
const L = fs.readFileSync(src, 'utf8').split(/\r?\n/);
const idx = (s) => L.findIndex((l) => l.trim() === s);
const out = (n, d) => fs.writeFileSync(new URL(`./data/${n}.json`, import.meta.url), JSON.stringify(d, null, 2));
fs.mkdirSync(new URL('./data/', import.meta.url), { recursive: true });
const list = (s) => s.split(' · ').map((x) => x.trim()).filter(Boolean);

// ---- cases
const cs = idx('13.2 Case studies'), ce = idx('13.3 Expertise pillars');
const keys = { 'Discipline': 'discipline', 'Filter': 'filter', 'Industry': 'industry', 'Instagram': 'instagram', 'Doubt': 'doubt', 'Move': 'move', 'Brand context': 'context', 'Brand': 'brand', 'Challenge': 'challenge', 'Objective': 'objective', 'Insight': 'insight', 'Strategy': 'strategy', 'What shipped': 'shipped', 'My contribution': 'contribution', 'Channels & tools': 'channels' };
const cases = []; let cur = null, inExec = false;
for (let i = cs + 1; i < ce; i++) {
  const l = L[i].trim(); if (!l) continue;
  const h = l.match(/^(\d\d) · (.+?) \(([a-z-]+)\)( — IN-HOUSE)?$/);
  if (h) {
    const [full, sub] = h[2].split(' — ');
    cur = { n: h[1], name: full, subtitle: sub || '', slug: h[3], inHouse: !!h[4], relationship: h[4] ? 'In-house role, Marketing Manager' : 'Speaker Box Agency client', org: h[4] ? 'Nexthara Scholarship (in-house)' : 'Speaker Box Agency', role: h[4] ? 'Marketing Manager' : 'Marketing Strategist', period: '', execution: [], visuals: [], metrics: [] };
    cases.push(cur); inExec = false; continue;
  }
  if (!cur) continue;
  if (l.startsWith('Context:')) { const p = l.match(/Period: (.+)$/); if (p) cur.period = p[1]; continue; }
  if (l === 'Execution:') { inExec = true; continue; }
  const m = l.match(/^([A-Za-z& ]+?): (.*)$/);
  if (m && keys[m[1]]) { inExec = false; cur[keys[m[1]]] = m[2]; continue; }
  if (inExec) cur.execution.push(l);
}
for (const c of cases) {
  c.doubt = c.doubt.replace(/^"|"$/g, '');
  c.discipline = list(c.discipline); c.context = list(c.context); c.channels = list(c.channels);
}
const featuredOrder = ['sign-laban', 'lapstore', 'mox-villas', 'gazania', 'nexthara'];
cases.forEach((c) => (c.featured = featuredOrder.indexOf(c.slug)));
out('cases', cases);
const slugOf = (name) => { const c = cases.find((c) => c.name === name || c.name.startsWith(name)); if (!c) throw new Error('no case ' + name); return c.slug; };

// ---- expertise
const es = ce, ee = idx('13.4 Experience'); const expertise = []; let e = null;
for (let i = es + 1; i < ee; i++) {
  const l = L[i].trim(); const h = l.match(/^(\d)\. (.+)$/);
  if (h) { e = { n: '0' + h[1], title: h[2], tools: [] }; expertise.push(e); continue; }
  const m = l.match(/^(Description|Capabilities|Seen in|Tools): (.*)$/); if (!m) continue;
  if (m[1] === 'Description') e.description = m[2];
  if (m[1] === 'Capabilities') e.capabilities = list(m[2]);
  if (m[1] === 'Seen in') e.seenIn = m[2].split(', ').map(slugOf);
  if (m[1] === 'Tools') e.tools = list(m[2]);
}
out('expertise', expertise);

// ---- experience + education
const xs = ee, xe = idx('13.5 Toolkit'); const roles = [];
for (let i = xs + 1; i < xe; i++) {
  const l = L[i].trim();
  if (l.startsWith('Summary:')) {
    const p = L[i - 1].trim().split(' · ');
    const r = { org: p[0], title: p[1], period: p[2], summary: l.slice(9), highlights: list(L[i + 1].trim().replace(/^Highlights: /, '')), cases: [] };
    if (r.org.startsWith('Speaker Box')) r.cases = cases.filter((c) => !c.inHouse).map((c) => c.slug);
    if (r.org.startsWith('Nexthara')) r.cases = ['nexthara'];
    r.current = /Present/.test(r.period); roles.push(r);
  }
}
const callout = L.slice(xs, xe).find((l) => l.startsWith('Closing callout:')).trim().match(/^Closing callout: "(.+?)" (.+)$/);
const eds = L.findIndex((l) => l.startsWith('Qualification\t'));
const education = []; for (let i = eds + 1; L[i].includes('\t'); i++) { const [q, inst, period] = L[i].trim().split('\t'); education.push({ qualification: q, institution: inst, period }); }
out('experience', { roles, callout: { title: callout[1], text: callout[2] }, education, languages: [['Malayalam', 'Native'], ['English', 'Fluent']] });

// ---- toolkit + roster
const table = (head) => { const s = L.findIndex((l) => l.startsWith(head)); const r = []; for (let i = s + 1; L[i] && L[i].includes('\t'); i++) { const [a, b] = L[i].trim().split('\t'); r.push({ group: a, items: b.split(', ') }); } return r; };
out('toolkit', table('Group\tTools'));
const roster = table('Industry\tBrands'); out('roster', roster);

console.log('cases', cases.length, 'agency', cases.filter((c) => !c.inHouse).length, 'roster brands', roster.reduce((a, r) => a + r.items.length, 0), 'industries', roster.length, 'filters', [...new Set(cases.map((c) => c.filter))].length);
console.log(cases.map((c) => `${c.n} ${c.name} [${c.execution.length}] ${Object.keys(keys).filter((k) => !c[keys[k]] || !c[keys[k]].length).join(',')}`).join('\n'));
console.log(JSON.stringify(roles.map((r) => [r.org, r.title, r.period, r.highlights.length])), education.length, expertise.map((e) => e.seenIn.length + '/' + e.tools.length).join(' '));
