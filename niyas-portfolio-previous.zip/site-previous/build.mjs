// Static generator: reads /data/*.json, writes the home page and 12 case pages.
// node build.mjs            -> dist/     (clean URLs: work/slug/)
// node build.mjs --preview  -> preview/  (explicit index.html links, for file:// and sandboxed previews)
import fs from 'node:fs';
import path from 'node:path';
const PREVIEW = process.argv.includes('--preview');
const OUT = PREVIEW ? 'preview' : 'dist';
const IDX = PREVIEW ? 'index.html' : '';
const J = (n) => JSON.parse(fs.readFileSync(`data/${n}.json`, 'utf8'));
const site = J('site'), cases = J('cases'), expertise = J('expertise'), exp = J('experience'), toolkit = J('toolkit'), roster = J('roster');
const bySlug = Object.fromEntries(cases.map((c) => [c.slug, c]));
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const q = (s) => `“${esc(s)}”`;
const has = (v) => (Array.isArray(v) ? v.length > 0 : !!v);
const YEAR = new Date().getFullYear();
const abs = (p) => (site.domain ? site.domain.replace(/\/$/, '') + '/' + p : '');

const ICON = {
  arrow: '<path d="M5 12h14M12 5l7 7-7 7"/>', up: '<path d="M12 19V5M5 12l7-7 7 7"/>', ext: '<path d="M7 7h10v10M7 17 17 7"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>', phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>', check: '<path d="M20 6 9 17l-5-5"/>',
  compass: '<circle cx="12" cy="12" r="10"/><path d="m16.24 7.76-2.12 6.36-6.36 2.12 2.12-6.36z"/>', trend: '<path d="M22 7 13.5 15.5l-5-5L2 17"/><path d="M16 7h6v6"/>',
  bulb: '<path d="M9 18h6M10 22h4"/><path d="M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5A4.61 4.61 0 0 1 8.91 14"/>', route: '<circle cx="6" cy="19" r="3"/><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15"/><circle cx="18" cy="5" r="3"/>', user: '<circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', menu: '<path d="M3 7h18M3 17h18"/>', x: '<path d="M18 6 6 18M6 6l12 12"/>', download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
};
const icon = (n, cls = '') => `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICON[n]}</svg>`;
const copyBtn = (label) => `<button class="copy-btn" type="button" data-copy="${esc(site.email)}">${icon('copy', 'i-copy')}${icon('check', 'i-check')}<span>${label}</span></button>`;
const ext = (href, label) => `<a class="link" href="${esc(href)}" target="_blank" rel="noopener">${label} ${icon('ext')}<span class="sr-only">(opens in new tab)</span></a>`;

function shell({ R, title, desc, ogImg, ogPath, jsonld, body, page }) {
  const home = R + IDX || './';
  const a = (hash) => (page === 'home' ? hash : home + hash);
  const links = [['Home', '#main'], ['About', '#about'], ['Expertise', '#expertise'], ['Projects', '#work'], ['Contact', '#contact']];
  const navLink = ([l, h]) => (l === 'Home' ? `<a href="${page === 'home' ? '#main' : home}"${page === 'home' ? ' aria-current="page"' : ''}>Home</a>` : `<a href="${a(h)}">${l}</a>`);
  const cv = has(site.cv) ? `<a class="link" href="${R}${site.cv}" download>${icon('download')} Download CV</a>` : '';
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
${site.domain ? `<link rel="canonical" href="${abs(ogPath)}">` : ''}
<meta property="og:type" content="${page === 'home' ? 'profile' : 'article'}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:image" content="${site.domain ? abs(ogImg) : R + ogImg}">
<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#0E0E0C">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='6' fill='%230E0E0C'/%3E%3Ctext x='7' y='23' font-family='Georgia,serif' font-size='20' font-weight='700' fill='%23F2EFE8'%3EN%3C/text%3E%3Ccircle cx='24.5' cy='21' r='2.2' fill='%23FF5B2E'/%3E%3C/svg%3E">
<link rel="preload" href="${R}assets/fonts/fraunces-latin-opsz-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="${R}assets/fonts/geist-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="${R}css/tokens.css">
<link rel="stylesheet" href="${R}css/base.css">
<link rel="stylesheet" href="${R}css/components.css">
<link rel="stylesheet" href="${R}css/sections.css">
<link rel="stylesheet" href="${R}css/nav.css">
${page === 'home' ? `<link rel="preload" href="${R}assets/fonts/poppins-latin-600-normal.woff2" as="font" type="font/woff2" crossorigin>\n<link rel="stylesheet" href="${R}css/hero.css">` : ''}
<link rel="stylesheet" href="${R}css/motion.css">
<script>document.documentElement.classList.add('js')</script>
${jsonld.map((j) => `<script type="application/ld+json">${JSON.stringify(j)}</script>`).join('\n')}
</head>
<body data-page="${page}">
<a class="skip" href="#main">Skip to content</a>
<header class="header" data-header>
  <div class="progress" data-progress aria-hidden="true"></div>
  <div class="container">
    <a class="wordmark" href="${home}" aria-label="Muhammed Niyas, home">MUHAMMED NIYAS</a>
    <nav class="nav" aria-label="Primary">
      ${links.map(navLink).join('\n      ')}
    </nav>
    <a class="talk" href="${a('#contact')}">Let’s Talk ${icon('ext')}</a>
    <button class="menu-btn" type="button" data-menu-open aria-haspopup="dialog" aria-label="Open menu">${icon('menu')}</button>
  </div>
</header>
<dialog class="menu" data-menu aria-label="Menu">
  <div class="menu-inner">
    <div class="menu-top"><span class="wordmark">MUHAMMED NIYAS</span><button class="menu-btn" style="display:inline-flex" type="button" data-menu-close aria-label="Close menu">${icon('x')}</button></div>
    <nav class="menu-links" aria-label="Menu">${links.map(navLink).join('')}</nav>
    <div class="menu-foot"><a class="link" href="mailto:${site.email}">${icon('mail')} ${site.email}</a>${cv}<a class="btn btn-primary" href="${a('#contact')}">Let’s Talk ${icon('arrow')}</a></div>
  </div>
</dialog>
<main id="main">
${body}
</main>
<footer class="footer">
  <div class="container">
    <div class="footer-mark" aria-hidden="true">NIYAS<span>.</span></div>
    <div class="footer-cols">
      <p>Marketing Strategist. Brand positioning, content and growth.</p>
      <p>Brand strategy for businesses that need to be understood before they can be chosen.<b>${esc(site.tagline)}</b></p>
      <div><a class="link" href="#main">Back to top ${icon('up')}</a><span>© ${YEAR} ${esc(site.name)}</span></div>
    </div>
  </div>
</footer>
<div class="sr-only" aria-live="polite" data-live></div>
<script defer src="${R}js/vendor/gsap.min.js"></script>
<script defer src="${R}js/vendor/ScrollTrigger.min.js"></script>
<script defer src="${R}js/vendor/SplitText.min.js"></script>
<script defer src="${R}js/vendor/Flip.min.js"></script>
<script defer src="${R}js/vendor/lenis.min.js"></script>
<script type="module" src="${R}js/main.js"></script>
</body>
</html>`;
}

const caseHref = (R, slug) => `${R}work/${slug}/${IDX}`;
const meta = (c) => `${c.n} · ${esc(c.filter)} · ${esc(c.relationship)}`;
const sectionHead = (n, label, h2, cls = 'display-l') => `<div class="rail"><span class="mono" data-index>${n} / ${label}</span></div>
      <div class="content"><h2 class="${cls} section-h2" data-h2>${h2}</h2>`;

function home() {
  const R = '';
  const featured = cases.filter((c) => c.featured >= 0).sort((a, b) => a.featured - b.featured);
  const filters = ['Food & Beverage', 'Retail & E-commerce', 'Fashion & Fitness', 'Real Estate', 'Education'];
  const photo = (src, alt, n, label, ratio, file, eager) => has(src)
    ? `<img class="ph-media" src="${src}" alt="${esc(alt)}" width="1200" height="${ratio === '4:5' ? 1500 : 1600}"${eager ? ' fetchpriority="high"' : ' loading="lazy"'} decoding="async">`
    : `<div class="ph-media ph-empty" role="img" aria-label="Placeholder for ${label.toLowerCase()}, photograph not yet supplied"><span class="tag">Placeholder</span><span><b>Photo ${n} · ${label}</b>${ratio} crop. Set in data/site.json:<br><code>${file}</code></span></div>`;
  // every floating element is four layers: scroll drift > cursor depth > entrance > idle float
  const fl = (cls, kind, scroll, depth, inner) => `<div class="fl ${cls}" data-scroll="${scroll}"><div data-depth="${depth}"><div data-load data-in="${kind}"><div class="fl-f">${inner}</div></div></div></div>`;
  const glass = (n, ic, title, text, scroll, depth) => fl(`gc gc-${n}`, 'card', scroll, depth, `<div class="glass"><span class="ic">${icon(ic)}</span><p><b>${title}</b><span>${text}</span></p></div>`);
  const hero = `<section class="hero" aria-label="Introduction" data-hero>
  <div class="h-frame" data-hero-frame>
    <div class="h-copy" data-hero-copy>
      <p class="h-avail" data-load data-in="text"><i aria-hidden="true"></i>Open to Strategic Opportunities</p>
      <h1 data-load data-hero-h1><span class="hline lt"><span class="hi">Turning Ideas Into</span></span> <span class="hline"><span class="hi"><span class="o">Strategies</span> That Drive</span></span> <span class="hline"><span class="hi"><span class="o">Brand Growth.</span></span></span></h1>
      <p class="h-desc" data-load data-in="text">Marketing Strategist focused on building meaningful brand experiences through strategy, creativity, and performance.</p>
      <div class="h-cta" data-load data-in="text">
        <a class="h-btn h-btn-1" href="#work">Explore My Work ${icon('ext')}</a>
        <a class="h-btn h-btn-2" href="#contact">Let’s Connect</a>
      </div>
    </div>
    ${glass(1, 'compass', 'Brand Strategy', 'Turning business challenges into clear directions.', -70, 22)}
    ${glass(2, 'trend', 'Performance Marketing', 'Data-driven campaigns. Measurable growth.', -110, 26)}
    <div class="h-stage">
      <div class="h-duo" data-scene>
        ${fl('ps', 'support', -90, 10, `<figure class="ph">${photo(site.heroSupport, `${site.name}, second portrait`, 2, 'Secondary portrait', '3:4', 'assets/img/hero-support.jpg', false)}</figure>`)}
        ${fl('pm', 'main', -30, 5, `<figure class="ph">${photo(site.heroMain, `Portrait of ${site.name}, Marketing Strategist`, 1, 'Main portrait', '4:5', 'assets/img/hero-main.jpg', true)}</figure>`)}
        ${glass(3, 'bulb', 'Creative Thinking', 'Ideas that make brands memorable.', -140, 30)}
        ${glass(4, 'route', 'Digital Experience', 'Building meaningful customer journeys.', -60, 34)}
        ${glass(5, 'user', 'Marketing Strategist', 'Strategy meets creativity and performance.', -100, 18)}
      </div>
    </div>
    <div class="h-notes">
      <p class="h-note h-note-l" data-load data-in="text">Building Brands Through Strategy<small>Kerala, India · Working Globally</small></p>
      <p class="h-note h-note-r" data-load data-in="text">Strategy<i aria-hidden="true">|</i>Creativity<i aria-hidden="true">|</i>Performance</p>
    </div>
  </div>
</section>`;

  const card = (c, i) => `<a class="card${i % 2 ? ' flip' : ''}" href="${caseHref(R, c.slug)}" data-card>
        <div class="card-media" data-media>
          ${has(c.visuals)
            ? `<img src="${c.visuals[0].src}" alt="${esc(c.visuals[0].alt)}" width="${c.visuals[0].w}" height="${c.visuals[0].h}" loading="lazy" style="border-radius:var(--img-radius)">`
            : `<div class="type-panel"><div class="lines" aria-hidden="true"></div><div class="top"><span class="mono">The doubt</span><span class="mono">${c.n} / 12</span></div><p class="doubt"><span class="doubt-u">${q(c.doubt)}</span></p></div>`}
        </div>
        <div class="card-text">
          <div><span class="mono">${meta(c)}</span><h3 class="display-m card-name" style="view-transition-name:case-${c.slug}">${esc(c.name)}</h3></div>
          <div class="kv">${has(c.visuals) ? `<span class="mono">The doubt</span><p class="doubt display-s">${q(c.doubt)}</p>` : ''}<span class="mono">The move</span><p class="body-l move">${esc(c.move)}</p></div>
          <span class="readcase">Read case ${icon('arrow')}</span>
        </div>
      </a>`;

  const row = (c) => `<a class="row" href="${caseHref(R, c.slug)}" data-row data-filter="${esc(c.filter)}"${c.featured >= 0 ? ' data-featured hidden' : ''}>
          <span class="mono">${c.n}</span>
          <span><span class="brand"${c.featured >= 0 ? '' : ` style="view-transition-name:case-${c.slug}"`}>${esc(c.name)}</span><span class="doubt">${q(c.doubt)}</span></span>
          <span class="small muted disc">${esc(c.discipline[0])}</span>
          <span class="small mv">${esc(c.move)}</span>
          ${icon('arrow', 'arr')}
        </a>`;

  const count = (f) => cases.filter((c) => c.filter === f).length;
  const rosterTotal = roster.reduce((n, r) => n + r.items.length, 0);
  const work = `<section class="section" id="work">
  <div class="container">
    <div class="ledger">
      ${sectionHead('01', 'Work', 'Twelve brands. One question: <em>why would a customer hesitate?</em>')}
        <p class="body-l section-intro" data-reveal>Eleven from Speaker Box Agency and one in-house role. Each case starts with the customer’s doubt and ends with what shipped.</p>
      </div>
    </div>
    <div class="featured">
      ${featured.map(card).join('\n      ')}
    </div>
    <div class="ledger">
      <div class="rail"></div>
      <div class="content">
        <div class="filter" role="group" aria-label="Filter the case index by industry">
          <span class="mono">Case index</span>
          <button type="button" aria-pressed="true" data-f="All">All</button>
          ${filters.map((f) => `<button type="button" aria-pressed="false" data-f="${esc(f)}">${esc(f)}<sup>${count(f)}</sup></button>`).join('')}
        </div>
        <div class="rows" data-rows>
        ${cases.map(row).join('\n        ')}
        </div>
        <details class="roster" data-reveal>
          <summary><span class="t">Agency client roster: ${rosterTotal} brands across ${roster.length} industries.</span><span class="tog">${icon('plus')}<span class="when-closed">Show full roster</span><span class="when-open">Hide roster</span></span></summary>
          <p class="small muted" style="margin-top:8px">Speaker Box Agency clients.</p>
          <div class="roster-grid">${roster.map((r) => `<div><h3>${esc(r.group)}</h3><ul>${r.items.map((b) => `<li>${esc(b)}</li>`).join('')}</ul></div>`).join('')}</div>
        </details>
      </div>
    </div>
  </div>
</section>`;

  const L = (slug, t) => `<a href="${caseHref(R, slug)}">${t}</a>`;
  const steps = [
    ['Understand.', 'Understand Before You Execute.', 'The business, the audience, the category.', `${L('gazania', 'Gazania')}, where after 20+ years as Albake the value lived in the old name.`],
    ['Find the doubt.', '', 'The insight into why a customer hesitates.', `${L('lapstore', 'Lapstore')}, “Customers are not necessarily looking for the cheapest laptop. They are looking for a reliable laptop they can purchase without regretting the decision.”`],
    ['Strategy.', 'Strategy Before Tactics.', 'One move, one line.', `${L('oryx-village', 'Oryx Village')}, “Sell the place, not the plate.”`],
    ['Create.', 'Creativity With Purpose.', 'Pillars, briefs, a content system.', `${L('peltfit', 'Peltfit')}, three pillars: Performance, Community, Kerala Pride.`],
    ['Measure and learn.', 'Data Behind Decisions · Growth Through Continuous Learning.', 'Read it like a ledger, then adjust.', ''],
  ];
  const method = `<section class="section paper" id="method">
  <div class="container">
    <div class="ledger">
      ${sectionHead('02', 'Method', 'Understand before you execute.')}
      </div>
    </div>
    <ol class="steps" data-steps>
      <li class="scrub" aria-hidden="true" data-steps-line></li>
      ${steps.map(([t, p, d, eg], i) => `<li class="step" data-reveal><span class="mono">0${i + 1}</span><h3>${t}</h3>${p ? `<p class="principle">${p}</p>` : ''}<p>${d}</p>${eg ? `<p class="eg"><span class="mono">Example</span><br>${eg}</p>` : ''}</li>`).join('\n      ')}
    </ol>
    <blockquote class="pull method-quote" data-reveal>${esc(site.philosophy)}</blockquote>
  </div>
</section>`;

  const exps = `<section class="section" id="expertise">
  <div class="container">
    <div class="ledger">
      ${sectionHead('03', 'Expertise', 'Five disciplines, one way of thinking.')}
        <div class="acc" data-acc>
          ${expertise.map((e, i) => `<div class="acc-item">
            <h3 style="font:inherit"><button class="acc-btn" type="button" id="acc-b${i}" aria-expanded="${i === 0}" aria-controls="acc-p${i}"><span class="mono">${e.n}</span><span class="t">${esc(e.title)}</span>${icon('plus')}</button></h3>
            <div class="acc-panel${i === 0 ? ' is-open' : ''}" id="acc-p${i}" role="region" aria-labelledby="acc-b${i}"><div><div class="acc-body">
              <p class="body-l">${esc(e.description)}</p>
              <div>
                <div class="kv"><span class="mono">Capabilities</span><div class="chips">${e.capabilities.map((x) => `<span class="chip">${esc(x)}</span>`).join('')}</div></div>
                <div class="kv"><span class="mono">Seen in</span><div class="chips">${e.seenIn.map((s) => `<a class="chip" href="${caseHref(R, s)}">${esc(bySlug[s].name)} →</a>`).join('')}</div></div>
                ${has(e.tools) ? `<div class="kv"><span class="mono">Tools</span><p class="small">${e.tools.map(esc).join(', ')}</p></div>` : ''}
              </div>
            </div></div></div>
          </div>`).join('\n          ')}
        </div>
      </div>
    </div>
  </div>
</section>`;

  const experience = `<section class="section" id="experience" style="padding-top:0">
  <div class="container">
    <div class="ledger">
      ${sectionHead('04', 'Experience', 'Experience built through execution.')}
      </div>
    </div>
    <div class="timeline" data-timeline>
      <div class="tl-track" aria-hidden="true"><i data-timeline-fill></i></div>
      ${exp.roles.map((r) => `<article class="tl-item ledger${r.current ? ' current' : ''}">
        <span class="tl-node" aria-hidden="true"></span>
        <div class="rail"><span class="mono">${esc(r.period)}</span></div>
        <div class="content" data-reveal>
          <h3 class="display-m">${esc(r.org)}</h3>
          <span class="mono tl-title">${esc(r.title)}${r.current ? ' · Current' : ''}</span>
          <p>${esc(r.summary)}</p>
          <ul class="hl">${r.highlights.map((h) => `<li>${esc(h)}</li>`).join('')}</ul>
          ${has(r.cases) ? `<div class="chips">${r.cases.map((s) => `<a class="chip" href="${caseHref(R, s)}">${esc(bySlug[s].name)}</a>`).join('')}</div>` : ''}
        </div>
      </article>`).join('\n      ')}
    </div>
    <div class="ledger"><div class="rail"></div><div class="content"><aside class="callout" data-reveal><h3 class="display-m">${esc(exp.callout.title)}</h3><p class="body-l">${esc(exp.callout.text)}</p></aside></div></div>
  </div>
</section>`;

  const about = `<section class="section paper" id="about">
  <div class="container">
    <div class="ledger">
      ${sectionHead('05', 'About', 'Not just marketing. <em>Understanding business.</em>')}
        <div class="about-grid${has(site.portrait) ? ' has-portrait' : ''}">
          <div class="about-text" data-reveal>${site.about.map((p) => `<p>${esc(p)}</p>`).join('')}</div>
          ${has(site.portrait) ? `<figure class="portrait"><img src="${site.portrait}" alt="Portrait of ${esc(site.name)}" width="800" height="1000" loading="lazy"></figure>` : ''}
        </div>
        <h3 class="mono sub-h">Education</h3>
        <div data-reveal>${exp.education.map((e) => `<div class="lrow"><span>${esc(e.qualification)}</span><span class="muted">${esc(e.institution)}</span><span class="mono">${esc(e.period)}</span></div>`).join('')}</div>
        <h3 class="mono sub-h">Languages</h3>
        <div data-reveal>${exp.languages.map(([l, lv]) => `<div class="lrow"><span>${l}</span><span></span><span class="mono">${lv}</span></div>`).join('')}</div>
      </div>
    </div>
  </div>
</section>`;

  const tk = `<section class="section" id="toolkit">
  <div class="container">
    <div class="ledger">
      ${sectionHead('06', 'Toolkit', 'The tools behind the thinking.')}
        <div data-reveal>${toolkit.map((g) => `<div class="tk"><h3>${esc(g.group)}</h3><p>${g.items.map(esc).join(', ')}</p></div>`).join('')}</div>
      </div>
    </div>
  </div>
</section>`;

  const contact = `<section class="section contact" id="contact" style="border-top:1px solid var(--rule-dark)">
  <div class="container">
    <span class="mono" data-index>07 / Contact</span>
    <h2 class="display-xl" data-h2 style="margin-top:var(--s5)">Have a brand people hesitate over? <em>Let’s find the strategy.</em></h2>
    <p class="body-l line" data-reveal>I’m open to Marketing Strategist roles in Dubai and the UAE, and to brands that need to be understood before they can be chosen.</p>
    <div class="channels" data-reveal>
      <div class="channel"><span class="mono">Email</span><span class="v"><a href="mailto:${site.email}">${site.email}</a>${copyBtn('Copy')}</span></div>
      <div class="channel"><span class="mono">Phone</span><span class="v"><a href="tel:${site.tel}">${esc(site.phone)}</a></span></div>
      <div class="channel"><span class="mono">Location</span><span class="v">${esc(site.location)}</span></div>
      ${has(site.linkedin) ? `<div class="channel"><span class="mono">LinkedIn</span><span class="v"><a href="${esc(site.linkedin)}" target="_blank" rel="noopener">LinkedIn<span class="sr-only"> (opens in new tab)</span></a></span></div>` : ''}
    </div>
    <div class="contact-cta" data-reveal>
      <a class="btn btn-primary" href="mailto:${site.email}" data-magnetic>Email me ${icon('arrow')}</a>
      ${has(site.cv) ? `<a class="btn btn-secondary" href="${site.cv}" download>Download CV (PDF)</a>` : ''}
    </div>
  </div>
</section>`;

  const person = { '@context': 'https://schema.org', '@type': 'Person', name: site.name, jobTitle: 'Marketing Strategist', worksFor: { '@type': 'Organization', name: 'Speaker Box Agency' }, address: { '@type': 'PostalAddress', addressRegion: 'Kerala', addressCountry: 'IN' }, knowsLanguage: ['ml', 'en'], email: 'mailto:' + site.email, ...(has(site.linkedin) ? { sameAs: [site.linkedin] } : {}) };
  return shell({
    R, page: 'home', ogImg: 'assets/og/home.png', ogPath: '',
    title: 'Muhammed Niyas | Marketing Strategist, Brand Positioning & Growth',
    desc: 'Muhammed Niyas, Marketing Strategist at Speaker Box Agency, Kerala. Brand positioning, content strategy and performance marketing across 12 case studies. Open to roles in Dubai and the UAE.',
    jsonld: [person, { '@context': 'https://schema.org', '@type': 'ProfilePage', mainEntity: { '@type': 'Person', name: site.name }, ...(site.domain ? { url: abs('') } : {}) }],
    body: [hero, work, method, exps, experience, about, tk, contact].join('\n'),
  });
}

function casePage(c, i) {
  const R = '../../';
  const prev = cases[(i + cases.length - 1) % cases.length], next = cases[(i + 1) % cases.length];
  const sentences = c.strategy.match(/^(.+?[.!?])\s+(.*)$/s);
  const lead = sentences ? sentences[1] : c.strategy, rest = sentences ? sentences[2] : '';
  const parts = [
    ['brand', 'The brand', `<p class="body-l">${esc(c.brand)}</p>`],
    ['challenge', 'The challenge', `<p>${esc(c.challenge)}</p>`],
    ['objective', 'The objective', `<p>${esc(c.objective)}</p>`],
    ['insight', 'The insight', `<blockquote class="pull">${esc(c.insight)}</blockquote>`, 'wide'],
    ['strategy', 'The strategy', `<p class="lead">${esc(lead)}</p>${rest ? `<p>${esc(rest)}</p>` : ''}`],
    ['execution', 'The execution', `<ol class="ruled">${c.execution.map((x, k) => `<li><span class="mono">${String(k + 1).padStart(2, '0')}</span><span>${esc(x)}</span></li>`).join('')}</ol>`],
    ['shipped', 'What shipped', `<p class="body-l">${esc(c.shipped)}</p>`],
    ['contribution', 'My contribution', `<p>${esc(c.contribution)}</p>`],
  ];
  const metaRows = [['Context', c.org], ['Role', c.role], ['Period', c.period]].filter(([, v]) => has(v));
  const body = `<article>
<header class="case-head">
  <div class="container">
    <nav class="crumb mono" aria-label="Breadcrumb"><a href="${R}${IDX}#work">Work</a><span aria-hidden="true">/</span><span>${c.n} of 12</span></nav>
    <h1 class="display-l" style="view-transition-name:case-${c.slug}" data-load-h1>${esc(c.name)}</h1>
    ${has(c.subtitle) ? `<p class="case-sub">${esc(c.subtitle)}</p>` : ''}
    <p class="case-disc small">${c.discipline.map(esc).join(' · ')}</p>
    <div class="case-pair">
      <dl class="meta">
        ${metaRows.map(([k, v]) => `<div><dt class="mono">${k}</dt><dd>${esc(v)}</dd></div>`).join('')}
        <div><dt class="mono">Relationship</dt><dd><span class="badge mono" style="color:var(--paper)">${esc(c.relationship)}</span></dd></div>
      </dl>
      <div class="dm">
        <div><span class="mono">The doubt</span><p class="doubt">${q(c.doubt)}</p></div>
        <div><span class="mono">The move</span><p class="body-l move">${esc(c.move)}</p></div>
      </div>
    </div>
    <div class="context case-context"><span class="mono">Brand context</span>${c.context.map((x) => `<span class="mono">${esc(x)}</span>`).join('')}</div>
  </div>
</header>
<div class="paper">
  <nav class="parts-nav" aria-label="Case sections" data-parts>
    <div class="container"><ol>${parts.map(([id, t], k) => `<li><a class="mono" href="#${id}">${String(k + 1).padStart(2, '0')} ${t}</a></li>`).join('')}</ol></div>
  </nav>
  <div class="section case-body">
    <div class="container">
      ${parts.map(([id, t, html, cls], k) => `<section class="part ledger" id="${id}" data-part>
        <div class="rail"><h2 class="mono">${String(k + 1).padStart(2, '0')} ${t}</h2></div>
        <div class="content${cls ? ' ' + cls : ''}">${html}</div>
      </section>`).join('\n      ')}
      ${has(c.metrics) ? `<section class="part ledger"><div class="rail"><h2 class="mono">Evidence</h2></div><div class="content wide"><div class="evidence">${c.metrics.map((m) => `<div><b>${esc(m.value)}</b><span>${esc(m.label)}</span><span class="small muted"> Source: ${esc(m.source)}</span></div>`).join('')}</div></div></section>` : ''}
      ${has(c.visuals) ? `<section class="part ledger"><div class="rail"><h2 class="mono">Visuals</h2></div><div class="content wide" style="columns:2;column-gap:var(--gutter)">${c.visuals.map((v) => `<img src="${R}${v.src}" alt="${esc(v.alt)}" width="${v.w}" height="${v.h}" loading="lazy" style="margin-bottom:var(--gutter)">`).join('')}</div></section>` : ''}
      <section class="part ledger">
        <div class="rail"><h2 class="mono">Channels &amp; tools</h2></div>
        <div class="content wide"><div class="chips">${c.channels.map((x) => `<span class="chip">${esc(x)}</span>`).join('')}</div><div class="case-ig">${ext(c.instagram, 'View on Instagram')}</div></div>
      </section>
    </div>
  </div>
</div>
</article>
<nav class="case-next" aria-label="More case studies">
  <div class="container">
    <div class="pn">
      ${[['Previous', prev], ['Next', next]].map(([l, p]) => `<a href="${caseHref(R, p.slug)}"><span class="mono">${l} · ${p.n}</span><span class="display-m" style="font-family:var(--font-display)">${esc(p.name)}</span><span class="doubt">${q(p.doubt)}</span></a>`).join('')}
    </div>
    <a class="btn btn-secondary allwork" href="${R}${IDX}#work">All work ${icon('arrow')}</a>
  </div>
</nav>`;
  return shell({
    R, page: 'case', ogImg: `assets/og/${c.slug}.png`, ogPath: `work/${c.slug}/`,
    title: `${c.name} Case Study | Muhammed Niyas`,
    desc: `“${c.doubt}” ${c.move}`,
    jsonld: [{ '@context': 'https://schema.org', '@type': 'CreativeWork', name: `${c.name} case study`, headline: c.move, about: c.industry, abstract: c.insight, author: { '@type': 'Person', name: site.name }, ...(site.domain ? { url: abs(`work/${c.slug}/`) } : {}) }],
    body,
  });
}

// ---- write
const w = (p, s) => { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, s); };
fs.rmSync(OUT, { recursive: true, force: true });
w(`${OUT}/index.html`, home());
cases.forEach((c, i) => w(`${OUT}/work/${c.slug}/index.html`, casePage(c, i)));
fs.cpSync('src/css', `${OUT}/css`, { recursive: true });
fs.cpSync('src/js', `${OUT}/js`, { recursive: true });
fs.cpSync('data', `${OUT}/data`, { recursive: true });
fs.mkdirSync(`${OUT}/js/vendor`, { recursive: true });
for (const f of ['gsap', 'ScrollTrigger', 'SplitText', 'Flip']) fs.copyFileSync(`node_modules/gsap/dist/${f}.min.js`, `${OUT}/js/vendor/${f}.min.js`);
fs.copyFileSync('node_modules/lenis/dist/lenis.min.js', `${OUT}/js/vendor/lenis.min.js`);
fs.mkdirSync(`${OUT}/assets/fonts`, { recursive: true });
for (const wgt of [400, 500, 600]) fs.copyFileSync(`node_modules/@fontsource/poppins/files/poppins-latin-${wgt}-normal.woff2`, `${OUT}/assets/fonts/poppins-latin-${wgt}-normal.woff2`);
for (const [pkg, f] of [['fraunces', 'fraunces-latin-opsz-normal'], ['fraunces', 'fraunces-latin-opsz-italic'], ['geist', 'geist-latin-wght-normal'], ['geist-mono', 'geist-mono-latin-wght-normal']]) fs.copyFileSync(`node_modules/@fontsource-variable/${pkg}/files/${f}.woff2`, `${OUT}/assets/fonts/${f}.woff2`);
if (fs.existsSync('og')) fs.cpSync('og', `${OUT}/assets/og`, { recursive: true });
if (fs.existsSync('static')) fs.cpSync('static', OUT, { recursive: true });
w(`${OUT}/robots.txt`, `User-agent: *\nAllow: /\n${site.domain ? `Sitemap: ${abs('sitemap.xml')}\n` : ''}`);
if (site.domain) w(`${OUT}/sitemap.xml`, `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${['', ...cases.map((c) => `work/${c.slug}/`)].map((p) => `  <url><loc>${abs(p)}</loc></url>`).join('\n')}\n</urlset>\n`);
console.log('built', OUT, 1 + cases.length, 'pages');
